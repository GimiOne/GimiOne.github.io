localStorage.setItem('cache',12);
console.log(localStorage.getItem('cache');